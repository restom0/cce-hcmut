import { Component } from '@angular/core';

@Component({
  selector: 'app-bt6',
  standalone: true,
  imports: [],
  templateUrl: './bt6.component.html',
  styleUrl: './bt6.component.css'
})
export class Bt6Component {

}
