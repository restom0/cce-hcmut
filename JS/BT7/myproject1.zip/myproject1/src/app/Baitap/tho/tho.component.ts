import { Component } from '@angular/core';

@Component({
  selector: 'app-tho',
  standalone: true,
  imports: [],
  templateUrl: './tho.component.html',
  styleUrl: './tho.component.css'
})
export class ThoComponent {

}
