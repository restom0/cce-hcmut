import { Component } from '@angular/core';

@Component({
  selector: 'app-bt8',
  standalone: true,
  imports: [],
  templateUrl: './bt8.component.html',
  styleUrl: './bt8.component.css'
})
export class Bt8Component {

}
