import { Component } from '@angular/core';

@Component({
  selector: 'app-bt7',
  standalone: true,
  imports: [],
  templateUrl: './bt7.component.html',
  styleUrl: './bt7.component.css'
})
export class Bt7Component {

}
