import { Component } from '@angular/core';

@Component({
  selector: 'app-shophoa',
  standalone: true,
  imports: [],
  templateUrl: './shophoa.component.html',
  styleUrl: './shophoa.component.css'
})
export class ShophoaComponent {

}
