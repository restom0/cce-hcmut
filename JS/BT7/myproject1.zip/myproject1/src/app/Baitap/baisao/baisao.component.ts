import { Component } from '@angular/core';

@Component({
  selector: 'app-baisao',
  standalone: true,
  imports: [],
  templateUrl: './baisao.component.html',
  styleUrl: './baisao.component.css'
})
export class BaisaoComponent {

}
