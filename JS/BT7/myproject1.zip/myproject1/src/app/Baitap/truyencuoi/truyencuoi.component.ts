import { Component } from '@angular/core';

@Component({
  selector: 'app-truyencuoi',
  standalone: true,
  imports: [],
  templateUrl: './truyencuoi.component.html',
  styleUrl: './truyencuoi.component.css'
})
export class TruyencuoiComponent {

}
