import { Component } from '@angular/core';

@Component({
  selector: 'app-bt9',
  standalone: true,
  imports: [],
  templateUrl: './bt9.component.html',
  styleUrl: './bt9.component.css'
})
export class Bt9Component {

}
