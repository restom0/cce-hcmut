<div class="sliderclass kad-mobile-slider">
<div id="imageslider" class="container">
			<div class="videofit">
                  <?php global $virtue; echo $virtue['mobile_video_embed'];?>
                  </div>
        </div><!--Container-->
</div><!--feat-->