<?php get_header(); ?>
<?php get_sidebar(); ?>

<div id="main">
    <!--Begin main -->


		<h1>Not Found </h1>
		<p>We respect your curiosity! But, what you are looking is not present here. Don't be disappointed, keep the spirits high, keep learning, keep finding! Curiosity is good, first step towards innovation. </p>

</div><!--End main -->
</div><!-- End center -->
</div><!--End primary-->

<?php get_footer();