<?php
/**
 * @var string $type
 */
?>

<div class="yit-panel-sidebar-widget-badge <?php echo $type; ?>">
    <div class="yit-panel-sidebar-widget-badge-s1"></div>
    <div class="yit-panel-sidebar-widget-badge-s2"></div>
    <div class="yit-panel-sidebar-widget-badge-text"><?php echo $text ?></div>
</div>