<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package WordPress
 * @subpackage Fruitful theme
 * @since Fruitful theme 1.0
 */

	get_header(); 
?>
	<?php fruitful_get_content_with_custom_sidebar('blogright'); ?>
	
<?php 
	get_footer(); 
?>