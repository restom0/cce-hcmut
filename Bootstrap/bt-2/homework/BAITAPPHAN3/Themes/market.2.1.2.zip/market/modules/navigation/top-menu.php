<div id="top-menu">
    <?php wp_nav_menu( array( 'theme_location' => 'top' ) ); ?>
</div>