<div id="header-2">
    <div class="container">
        <?php get_template_part('modules/navigation/primary','menu'); ?>

        <div id="top-search" class="col-md-1 col-xs-12">
            <?php // get_search_form(); ?>
        </div>
    </div>
</div>
