<?php  if ( is_active_sidebar( 'envo-ecommerce-right-sidebar' ) ) { ?>
	<aside id="sidebar" class="col-md-4">
		<?php dynamic_sidebar( 'envo-ecommerce-right-sidebar' ); ?>
	</aside>
<?php } ?>
