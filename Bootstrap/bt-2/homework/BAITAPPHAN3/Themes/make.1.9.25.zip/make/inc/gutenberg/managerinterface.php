<?php
/**
 * @package Make
 */

interface MAKE_Gutenberg_ManagerInterface {}