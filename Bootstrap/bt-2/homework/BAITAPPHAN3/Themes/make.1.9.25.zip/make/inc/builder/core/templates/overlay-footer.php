			</div>
			<div class="ttfmake-overlay-footer">
				<span class="ttfmake-overlay-close-update button button-primary button-large" aria-hidden="true"><?php echo $ttfmake_overlay_button_label; ?></span>
			</div>
		</div>
	</div>
</div>